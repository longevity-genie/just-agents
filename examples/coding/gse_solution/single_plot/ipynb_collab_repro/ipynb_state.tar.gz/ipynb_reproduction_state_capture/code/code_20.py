import GEOparse
from pathlib import Path

# Re-download the GSE148911 dataset
file_path = Path('./input')
gse148911 = GEOparse.get_GEO('GSE148911', destdir=str(file_path), silent=True)

# Inspect the first few GSMs again to check if the issue is resolved
for gsm_name, gsm in gse148911.gsms.items():
    print(gsm.table.head())
    break  # Only print the first GSM to avoid too much output

# Check the available columns in the GSM table
print("Available columns in GSM table:", gsm.table.columns)