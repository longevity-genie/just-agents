import GEOparse

gse_id = 'GSE176043'
gse = GEOparse.get_GEO(gse_id, destdir='./input', silent=True)

# Check if the download was successful by listing the files in the directory
import os
files = os.listdir('./input')
files