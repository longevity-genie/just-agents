import pandas as pd
from pathlib import Path

# Load the normalized data for GSE176043
file_path = Path('./input/GSE176043_normalized.csv')
data = pd.read_csv(file_path)

# Display the first few rows of the dataset to understand its structure
print(data.head())

# Check for missing values
print(data.isnull().sum())

# Check the shape of the dataset
print(data.shape)