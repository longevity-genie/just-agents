import GEOparse
from pathlib import Path

# Re-download the GSE144600 dataset
file_path = Path('./input')
gse144600 = GEOparse.get_GEO('GSE144600', destdir=str(file_path), silent=True)

# Inspect the first few GSMs again to check if the issue is resolved
for gsm_name, gsm in gse144600.gsms.items():
    print(gsm.table.head())
    break  # Only print the first GSM to avoid too much output

# Check the available columns in the GSM table
print("Available columns in GSM table:", gsm.table.columns)