import GEOparse
import pandas as pd
from pathlib import Path

# Load the GSE41781 dataset
file_path = Path('./input/GSE41781_family.soft.gz')
gse41781 = GEOparse.get_GEO(filepath=str(file_path), silent=True)

# Extract the expression data
expression_data = gse41781.pivot_samples('VALUE')

# Display the first few rows of the dataset to understand its structure
print(expression_data.head())

# Check for missing values
print(expression_data.isnull().sum())

# Check the shape of the dataset
print(expression_data.shape)