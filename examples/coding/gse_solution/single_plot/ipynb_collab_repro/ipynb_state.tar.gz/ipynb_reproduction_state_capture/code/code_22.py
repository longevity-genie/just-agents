# Inspect the available fields in the GSE190986 dataset
print(dir(gse190986))

# Check the first few entries to understand the structure
for gsm_name, gsm in gse190986.gsms.items():
    print(gsm.table.head())
    break  # Only print the first GSM to avoid too much output