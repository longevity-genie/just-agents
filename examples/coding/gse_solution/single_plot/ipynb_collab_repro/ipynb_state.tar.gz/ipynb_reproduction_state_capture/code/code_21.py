import GEOparse
from pathlib import Path

# Load the GSE190986 dataset
file_path = Path('./input/GSE190986_family.soft.gz')
gse190986 = GEOparse.get_GEO(filepath=str(file_path), silent=True)

# Extract the expression data
expression_data_190986 = gse190986.pivot_samples('VALUE')

# Display the first few rows of the dataset to understand its structure
print(expression_data_190986.head())

# Check for missing values
print(expression_data_190986.isnull().sum())

# Check the shape of the dataset
print(expression_data_190986.shape)