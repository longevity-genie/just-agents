import GEOparse
from pathlib import Path

# Load the GSE144600 dataset
file_path = Path('./input/GSE144600_family.soft.gz')
gse144600 = GEOparse.get_GEO(filepath=str(file_path), silent=True)

# Extract the expression data
expression_data_144600 = gse144600.pivot_samples('VALUE')

# Display the first few rows of the dataset to understand its structure
print(expression_data_144600.head())

# Check for missing values
print(expression_data_144600.isnull().sum())

# Check the shape of the dataset
print(expression_data_144600.shape)