# Attempt to use pivot_and_annotate to extract expression data
try:
    expression_data_148911 = gse148911.pivot_and_annotate(values='VALUE')
    print(expression_data_148911.head())
except Exception as e:
    print(f"Error: {e}")