import GEOparse
from pathlib import Path

# Load the GSE148911 dataset
file_path = Path('./input/GSE148911_family.soft.gz')
gse148911 = GEOparse.get_GEO(filepath=str(file_path), silent=True)

# Inspect the available fields in the dataset
print(dir(gse148911))

# Check the first few entries to understand the structure
for gsm_name, gsm in gse148911.gsms.items():
    print(gsm.table.head())
    break  # Only print the first GSM to avoid too much output