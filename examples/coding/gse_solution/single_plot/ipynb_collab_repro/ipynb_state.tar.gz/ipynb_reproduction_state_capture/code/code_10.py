import GEOparse

# Load the GSE148911 dataset
file_path = Path('./input/GSE148911_family.soft.gz')
gse148911 = GEOparse.get_GEO(filepath=str(file_path), silent=True)

# Extract the expression data
expression_data_148911 = gse148911.pivot_samples('VALUE')

# Display the first few rows of the dataset to understand its structure
print(expression_data_148911.head())

# Check for missing values
print(expression_data_148911.isnull().sum())

# Check the shape of the dataset
print(expression_data_148911.shape)