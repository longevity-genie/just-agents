import GEOparse
from pathlib import Path

# Load the GSE144600 dataset
file_path = Path('./input/GSE144600_family.soft.gz')
gse144600 = GEOparse.get_GEO(filepath=str(file_path), silent=True)

# Inspect the available fields in the GSE144600 dataset
print(dir(gse144600))

# Check the first few entries to understand the structure
for gsm_name, gsm in gse144600.gsms.items():
    print(gsm.table.head())
    break  # Only print the first GSM to avoid too much output