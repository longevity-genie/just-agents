import GEOparse
from pathlib import Path

# Load the GSE148911 dataset
file_path = Path('./input/GSE148911_family.soft.gz')
gse148911 = GEOparse.get_GEO(filepath=str(file_path), silent=True)

# Inspect the first few GSMs to understand their structure
for gsm_name, gsm in gse148911.gsms.items():
    print(gsm.table.head())
    break  # Only print the first GSM to avoid too much output

# Check the available columns in the GSM table
print("Available columns in GSM table:", gsm.table.columns)