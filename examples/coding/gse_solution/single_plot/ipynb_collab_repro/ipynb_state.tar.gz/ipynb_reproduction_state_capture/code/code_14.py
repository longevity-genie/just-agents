import GEOparse
from pathlib import Path

# Load the GSE148911 dataset
file_path = Path('./input/GSE148911_family.soft.gz')
gse148911 = GEOparse.get_GEO(filepath=str(file_path), silent=True)

# Attempt to use pivot_and_annotate to extract expression data
try:
    expression_data_148911 = gse148911.pivot_and_annotate(values='VALUE')
    print(expression_data_148911.head())
except Exception as e:
    print(f"Error: {e}")