import GEOparse
from pathlib import Path

# Load the GSE190986 dataset
file_path = Path('./input/GSE190986_family.soft.gz')
gse190986 = GEOparse.get_GEO(filepath=str(file_path), silent=True)

# Inspect the available fields in the GSE190986 dataset
print(dir(gse190986))

# Check the first few entries to understand the structure
for gsm_name, gsm in gse190986.gsms.items():
    print(gsm.table.head())
    break  # Only print the first GSM to avoid too much output