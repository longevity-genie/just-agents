import GEOparse

# Download the remaining GEO datasets
remaining_gse_ids = ['GSE41781', 'GSE148911', 'GSE190986', 'GSE144600']

downloaded_files = []
for gse_id in remaining_gse_ids:
    gse = GEOparse.get_GEO(gse_id, destdir='./input', silent=True)
    downloaded_files.append(gse_id)

# List the downloaded files to confirm
import os
files = os.listdir('./input')
files