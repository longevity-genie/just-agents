# Inspect the available platforms in the GSE148911 dataset
gpls = gse148911.gpls
print("Available platforms:", list(gpls.keys()))

# Inspect the first platform to understand its structure
first_gpl = list(gpls.values())[0]
print(first_gpl.table.head())

# Check available columns for annotation
print("Available columns for annotation:", first_gpl.table.columns)